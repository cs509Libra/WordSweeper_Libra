-Server should run by simple double-clicking the .jar file, BUT:
	-Wll not display debug printouts
	-will be difficult to stop

-Better way: run from command line
on windows:
	-> cd path/to/folder

	-> java.exe Server_Aquarius.jar -jar

on Mac (Terminal):
	->